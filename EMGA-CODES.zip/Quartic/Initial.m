function [num_pop,num_par,num_iter,num_pop11,num_pop12,num_pop13,num_pop21,num_pop22,num_pop23,g1,g2]=Initial;
num_pop=50;%number of population
num_par=30;%number of parameters (variables of problem)
num_iter=1000;%number of iteration
%% adjustable parameters of algorithm
 g1=[2*10^-1 1*10^-1]; g2=[2*10^-1 1*10^-1];%refer table 2 of paper;%refer table 2 of paper g1=[maximumvalue minimumvalue]
num_pop11=0.2*num_pop;%number of population in group 1 in non-oscillation mood
num_pop12=0.3*num_pop;%number of population in group 2 in non-oscillation mood
num_pop13=0.5*num_pop;%number of population in group 3 in non-oscillation mood
num_pop21=0.2*num_pop;%number of population in group 1 in oscillation mood
num_pop22=0.5*num_pop;%number of population in group 2 in oscillation mood
num_pop23=0.3*num_pop;%number of population in group 3 in oscillation mood
%we could change the value of  num_pop11, num_pop12, num_pop13, num_pop21, num_pop22 and num_pop23  in
%some problms, specially value of "num_pop12 and num_pop13".
end