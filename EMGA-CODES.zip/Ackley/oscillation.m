function pop=oscillation(pop,iteration,limit_pop_up,limit_pop_dn)
[num_pop,num_par,num_iter,num_pop11,num_pop12,num_pop13,num_pop21,num_pop22,num_pop23,g1,g2]=Initial;

for j=num_pop21+1:num_pop
  risk=g1(1,1)-(g1(1,1)-g1(1,2))*(iteration/num_iter);risk2=g2(1,1)-(g2(1,1)-g2(1,2))*(iteration/num_iter);%eq. (8), refer to paper
  u=j/num_pop;%eq. (5)---refer to paper
  nt1=sum(abs(pop(j,:))); %eq. (6)---refer to paper
  ntt=sum(pop(j,:));
 pg=ntt;%refer to section 3.2.2.1 of paper
  %pg is information of market if you have some information about sum of
  %stocks, you can add the information in pg.  for example if you know that
  %sum of variable is 30 you can assume pg=30; it could  increase theconverging speed.
  %________________________________________________________________________
  if j<=num_pop22+num_pop21  %trading stocks in group 2
   %buying new stocks
      dnt1=abs(ntt-pg+(2*rand*u*risk*nt1));%eq. (4)---refer to paper  
         tt=ceil(rand*rand*num_par);% how many shares should change their values
         xx1 = rand*rand; x2n0 = rand(1,tt-1); sumx2n0 = sum(x2n0);xx2=[xx1,(1-xx1)*x2n0/sumx2n0];xx3=xx2*dnt1;%distribute "dnt1" to "tt" stocks randomly
        for h=1:tt
                 g=ceil(rand*num_par);
                 pop(j,g)=pop(j,g)+xx3(1,h);
        end
    %__________________________________________________________________________
    %selling new stocks
   nt2=sum(pop(j,:));dnt2=abs(nt2-pg);%eq. (9)---refer to paper
   an=nt2-pg;
   tt=ceil(rand*rand*num_par);% how many shares should change their values
   xx1 = rand*rand; x2n0 = rand(1,tt-1); sumx2n0 = sum(x2n0);xx2=[xx1,(1-xx1)*x2n0/sumx2n0];xx3=xx2*dnt2;%distribute "dnt2" to "tt" stocks randomly   
   for h=1:tt
                 g=ceil(rand*num_par);
                 if an>0
                      d11=pop(j,g)-xx3(1,h);
                 else
                      d11=pop(j,g)+xx3(1,h);
                 end
                      pop(j,g)=d11;
   end
%__________________________________________________________________________
else      %trading stock in group 3
    rs=0.5-rand;%eq. (11)
    dnt3=(4*rs*u*risk2*nt1);%eq. (10)---refer to paper
    tt=ceil(rand*rand*num_par);
    xx1 = rand*rand; x2n0 = rand(1,tt-1); sumx2n0 = sum(x2n0);xx2=[xx1,(1-xx1)*x2n0/sumx2n0];xx3=xx2*dnt3;
      for h=1:tt
                 g=ceil(rand*num_par);
                 d1=pop(j,g)+xx3(1,h);
                    pop(j,g)=d1;  
      end
    
end
end
end
