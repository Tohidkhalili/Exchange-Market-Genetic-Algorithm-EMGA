function FC=fitness(pop)
[num_pop,num_par,num_iter,num_pop11,num_pop12,num_pop13,num_pop21,num_pop22,num_pop23,g1,g2]=Initial;
 for k=1:num_pop
 c=exp(1);a=0;b=0;
 for t=1:num_par
     a=a+(pop(k,t)^2);b=b+cos(2*pi*pop(k,t));
 end
 FC(1,k)=-20*exp(-.2*sqrt(a/num_par))+20-exp(b/num_par)+exp(1);
end
end