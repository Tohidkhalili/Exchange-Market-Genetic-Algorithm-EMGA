function pop=notoscillation(pop)
[num_pop,num_par,num_iter,num_pop11,num_pop12,num_pop13,num_pop21,num_pop22,num_pop23,g1,g2]=Initial;
for j=num_pop11+1:num_pop
   if j<=num_pop11+num_pop12
       person(1)=ceil(num_pop11*rand);person(2)=ceil(num_pop11*rand);r1=rand;
        pop(j,:)=r1*pop(person(1),:)+(1-r1)*pop(person(2),:);  %eq. (1)--refer to paper
   else
       c1=2;c2=2;r1=rand(1,num_par);r2=rand(1,num_par);
       person(1)=ceil(num_pop11*rand);person(2)=ceil(num_pop11*rand);
       comp(j,:)=c1*r1.*(pop(person(1),:)-pop(j,:))+c2*r2.*(pop(person(2),:)-pop(j,:));% eq. (2)---refer to paper 
       pop(j,:)=pop(j,:)+0.8*comp(j,:);% eq. (3)
   end
end
end
