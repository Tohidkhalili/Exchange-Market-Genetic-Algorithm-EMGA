function FC=fitness(pop)
[num_pop,num_par,num_iter,num_pop11,num_pop12,num_pop13,num_pop21,num_pop22,num_pop23,g1,g2]=Initial;
for k=1:num_pop
FC(k,1)=sum(pop(k,:).^2);
end
