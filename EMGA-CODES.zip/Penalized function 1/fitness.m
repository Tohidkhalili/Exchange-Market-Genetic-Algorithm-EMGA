function FC=fitness(pop)
[num_pop,num_par,num_iter,num_pop11,num_pop12,num_pop13,num_pop21,num_pop22,num_pop23,g1,g2]=Initial;
for k=1:num_pop
b=0;a=0;
for t=1:num_par
    y(t)=1+(pop(k,t)+1)/4;
    if (pop(k,t) > 10)
            u = 100 * (pop(k,t) - 10)^4;
        elseif (pop(k,t) < -10)
            u = 100 * (-pop(k,t) - 10)^4;
        else
            u = 0;
    end
    a=a+u;
end
a=a+(10 * (sin(2*pi*y(1)))^2 + (y(num_par) - 1)^2) * pi / num_par;
for t=1:num_par-1
    b=b+((y(t) - 1)^2 * (1 + 10 * (sin(2*pi*y(t+1)))^2)) * pi / num_par;
end
FC(1,k)=a+b;
end

