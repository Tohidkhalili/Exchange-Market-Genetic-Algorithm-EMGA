function FC=fitness(pop)
[num_pop,num_par,num_iter,num_pop11,num_pop12,num_pop13,num_pop21,num_pop22,num_pop23,g1,g2]=Initial;
for k=1:num_pop
a=0;b=0;c=0;
for t=1:num_par 
    if (pop(k,t)>5)
            u=100*(pop(k,t)-5)^4;
        elseif (pop(k,t)<-5)
            u=100*(-pop(k,t)-5)^4;
        else
            u=0;
    end
 c=c+u;
end
 b=b+((sin(pi*3*pop(k,1)))^2 +(pop(k,num_par)-1)^2*(1+(sin(2*pi*pop(k,num_par)))^2));
for t=1:29
    a=a+1*((pop(k,t)-1)^2*(1+(sin(3*pi*pop(k,t+1)))^2));
end
FC(1,k)=0.1*(a+b)+c;
end
end
